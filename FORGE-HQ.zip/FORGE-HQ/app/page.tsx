use client";

import { useEffect, useMemo, useState } from "react";

type Task = { id: number; title: string; done: boolean; priority: "High" | "Medium" | "Low" };
type Note = { id: number; text: string; date: string };
type Finance = { income: number; costs: number; stock: number };

const seedTasks: Task[] = [
  { id: 1, title: "Lock first FORGE hero tee specification", done: true, priority: "High" },
  { id: 2, title: "Confirm manufacturer / sample route", done: false, priority: "High" },
  { id: 3, title: "Finalise packaging sticker card", done: false, priority: "Medium" },
  { id: 4, title: "Prepare launch content batch", done: false, priority: "Medium" },
];

const nav = ["Overview", "Tasks", "Finance", "Products", "Launch", "Notes", "Goals"];

export default function Home() {
  const [active, setActive] = useState("Overview");
  const [tasks, setTasks] = useState<Task[]>(seedTasks);
  const [notes, setNotes] = useState<Note[]>([]);
  const [finance, setFinance] = useState<Finance>({ income: 0, costs: 0, stock: 0 });
  const [newTask, setNewTask] = useState("");
  const [newNote, setNewNote] = useState("");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("forge-hq");
    if (saved) {
      try {
        const data = JSON.parse(saved);
        if (data.tasks) setTasks(data.tasks);
        if (data.notes) setNotes(data.notes);
        if (data.finance) setFinance(data.finance);
      } catch {}
    }
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted) localStorage.setItem("forge-hq", JSON.stringify({ tasks, notes, finance }));
  }, [tasks, notes, finance, mounted]);

  const completed = tasks.filter(t => t.done).length;
  const progress = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;
  const profit = finance.income - finance.costs;

  const sectionTitle = active === "Overview" ? "Good to see you." : active;

  function addTask() {
    if (!newTask.trim()) return;
    setTasks([{ id: Date.now(), title: newTask.trim(), done: false, priority: "Medium" }, ...tasks]);
    setNewTask("");
  }

  function addNote() {
    if (!newNote.trim()) return;
    setNotes([{ id: Date.now(), text: newNote.trim(), date: new Date().toLocaleDateString("en-GB") }, ...notes]);
    setNewNote("");
  }

  const launchItems = [
    ["Brand direction", "Locked", 100],
    ["Hero product", "In progress", 75],
    ["Packaging", "In progress", 55],
    ["Website", "Next", 20],
    ["Launch content", "Next", 10],
  ] as const;

  const page = useMemo(() => {
    if (active === "Overview") return (
      <>
        <div className="hero">
          <div>
            <p className="eyebrow">FORGE HQ / OPERATING SYSTEM</p>
            <h1>{sectionTitle}</h1>
            <p className="muted">Build the brand. Keep showing up. No days owed.</p>
          </div>
          <div className="date">{new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}</div>
        </div>
        <div className="stats">
          <Card label="TASK PROGRESS" value={`${progress}%`} detail={`${completed} of ${tasks.length} complete`} />
          <Card label="NET POSITION" value={`£${profit.toFixed(0)}`} detail="Income minus tracked costs" />
          <Card label="PRODUCTS" value="1" detail="Hero product currently tracked" />
          <Card label="LAUNCH" value="41%" detail="Overall launch progress" />
        </div>
        <div className="grid two">
          <Panel title="Today">
            <TaskList tasks={tasks.slice(0, 4)} toggle={toggleTask} />
            <button className="linkBtn" onClick={() => setActive("Tasks")}>Open task manager →</button>
          </Panel>
          <Panel title="Launch pulse">
            {launchItems.map(([name, status, pct]) => <div className="progressRow" key={name}><div><b>{name}</b><span>{status}</span></div><div className="bar"><i style={{ width: `${pct}%` }} /></div></div>)}
          </Panel>
        </div>
        <div className="quote">“SHOW UP. PUT THE WORK IN. PROVIDE. REPEAT.”<small>— FORGE</small></div>
      </>
    );

    if (active === "Tasks") return (
      <Panel title="Task manager" subtitle="Keep the next actions visible.">
        <div className="inputRow"><input value={newTask} onChange={e => setNewTask(e.target.value)} onKeyDown={e => e.key === "Enter" && addTask()} placeholder="Add a task..." /><button onClick={addTask}>Add</button></div>
        <TaskList tasks={tasks} toggle={toggleTask} remove={id => setTasks(tasks.filter(t => t.id !== id))} />
      </Panel>
    );

    if (active === "Finance") return (
      <div className="grid two">
        <Panel title="Finance tracker" subtitle="Simple first version — saved on this device.">
          <MoneyField label="Income / sales" value={finance.income} set={v => setFinance({ ...finance, income: v })} />
          <MoneyField label="Business costs" value={finance.costs} set={v => setFinance({ ...finance, costs: v })} />
          <MoneyField label="Stock / inventory spend" value={finance.stock} set={v => setFinance({ ...finance, stock: v })} />
        </Panel>
        <Panel title="Position">
          <div className="bigMoney">£{profit.toFixed(2)}</div>
          <p className="muted">Current tracked net position</p>
        </Panel>
      </div>
    );

    if (active === "Products") return (
      <Panel title="Product board" subtitle="Core FORGE collection">
        <div className="product"><div className="productMark">F</div><div><b>Hero Heavyweight Tee</b><p>300 GSM • Washed black • Core collection</p><span className="tag">IN DEVELOPMENT</span></div></div>
        <div className="product"><div className="productMark">F</div><div><b>Women’s Core</b><p>Built by love. Forged by life.</p><span className="tag mutedTag">PLANNED</span></div></div>
        <div className="product"><div className="productMark">F</div><div><b>Kids / Minis</b><p>Forged to grow. No days owed.</p><span className="tag mutedTag">PLANNED</span></div></div>
      </Panel>
    );

    if (active === "Launch") return (
      <Panel title="Launch tracker" subtitle="One place to see what is moving.">
        {launchItems.map(([name, status, pct]) => <div className="launchItem" key={name}><div className="launchTop"><b>{name}</b><span>{pct}%</span></div><div className="bar"><i style={{ width: `${pct}%` }} /></div><small>{status}</small></div>)}
      </Panel>
    );

    if (active === "Notes") return (
      <Panel title="FORGE notebook" subtitle="Ideas, decisions and reminders.">
        <div className="inputRow"><input value={newNote} onChange={e => setNewNote(e.target.value)} onKeyDown={e => e.key === "Enter" && addNote()} placeholder="Write a note..." /><button onClick={addNote}>Save</button></div>
        {notes.length === 0 ? <p className="empty">No notes yet. Capture the next idea here.</p> : notes.map(n => <div className="note" key={n.id}><p>{n.text}</p><small>{n.date}</small></div>)}
      </Panel>
    );

    return (
      <Panel title="Goals" subtitle="Keep the bigger picture in view.">
        <Goal title="Launch FORGE core collection" pct={41} />
        <Goal title="Build a recognisable family lifestyle brand" pct={25} />
        <Goal title="Create a repeatable content engine" pct={15} />
        <Goal title="Reach financial freedom through the brand" pct={10} />
      </Panel>
    );
  }, [active, tasks, notes, finance, newTask, newNote, progress, completed, profit]);

  function toggleTask(id: number) {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  }

  return (
    <main>
      <aside>
        <div className="brand"><span>FORGE</span><small>HQ</small></div>
        <nav>{nav.map(item => <button className={active === item ? "active" : ""} key={item} onClick={() => setActive(item)}>{item}</button>)}</nav>
        <div className="sidebarBottom"><span className="statusDot" /> System active</div>
      </aside>
      <section className="content">
        <header><button className="mobileBrand" onClick={() => setActive("Overview")}>FORGE <span>HQ</span></button><div className="mobileDate">{new Date().toLocaleDateString("en-GB")}</div></header>
        {page}
        <footer>FORGE HQ <span>NO DAYS OWED</span></footer>
      </section>
    </main>
  );
}

function Card({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <div className="stat"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>;
}
function Panel({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return <div className="panel"><div className="panelHead"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div></div>{children}</div>;
}
function TaskList({ tasks, toggle, remove }: { tasks: Task[]; toggle: (id:number)=>void; remove?: (id:number)=>void }) {
  return <div className="tasks">{tasks.length === 0 ? <p className="empty">Nothing here yet.</p> : tasks.map(t => <div className={`task ${t.done ? "done" : ""}`} key={t.id}><button className="check" onClick={() => toggle(t.id)}>{t.done ? "✓" : ""}</button><div><b>{t.title}</b><small>{t.priority}</small></div>{remove && <button className="remove" onClick={() => remove(t.id)}>×</button>}</div>)}</div>;
}
function MoneyField({ label, value, set }: { label: string; value: number; set: (v:number)=>void }) {
  return <label className="money"><span>{label}</span><input type="number" min="0" value={value || ""} onChange={e => set(Number(e.target.value))} placeholder="0.00" /></label>;
}
function Goal({ title, pct }: { title: string; pct: number }) {
  return <div className="goal"><div><b>{title}</b><span>{pct}%</span></div><div className="bar"><i style={{width:`${pct}%`}} /></div></div>;
}