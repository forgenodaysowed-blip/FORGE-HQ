import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FORGE HQ",
  description: "The operating dashboard for FORGE.",
  applicationName: "FORGE HQ",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "FORGE HQ",
    statusBarStyle: "black-translucent",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0b0b0b",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}