# FORGE HQ

A mobile-first FORGE business operating dashboard built with Next.js.

## Deploy

Import this repository into Vercel. No environment variables are required for the first version.

## Data

The first version stores tasks, notes and finance values in the browser's localStorage. That means the data stays on the device/browser and is not yet shared between devices.

## Brand

FORGE — NO DAYS OWED.
